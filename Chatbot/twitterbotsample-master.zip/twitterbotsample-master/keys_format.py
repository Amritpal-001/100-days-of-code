# keys_format.py shares the same format as keys.py.
# This file is not meant to be used in the main script.
# Instead, copy this file into keys.py and put your own
# keys there.
CONSUMER_KEY = 'AAAAAA'
CONSUMER_SECRET = 'BBBBBB'
ACCESS_KEY = 'CCCCCC'
ACCESS_SECRET = 'DDDDDD'
